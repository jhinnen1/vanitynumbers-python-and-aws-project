import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('vanity_numbers_results')

def lambda_handler(event, context):
    table.put_item(
        Item={
            'id': 'customer_b',
            'customer_phone_number': '8009993333'
            
        }
    )
    response = {
        'message': 'Item added'
    }
    return {
        'statusCode': 200,
        'body': response
    }

