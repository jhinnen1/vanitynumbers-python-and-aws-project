import json
import boto3
import mnemonic

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('vanity_numbers_results')

def lambda_handler(event, context):
    table.put_item(
        Item={
            'id': 'customer_d',
            'customer_phone_number': '8005551111'
        }
    )    
    response = {
        'message': 'Item added'
    }
    return {
        'statusCode': 200,
        'body': response
    }