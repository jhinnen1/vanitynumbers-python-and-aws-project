import json
import boto3
import vanitynumber


dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('vanity_numbers_results')

vanity_numbers = vanitynumber.all_wordifications("1-800-266-5233")

def lambda_handler(event, context):
    table.put_item(
        Item={
            'id': 'customer_a',
            'customer phone number': '1-800-266-5233',
            'vanity numbers': vanity_numbers
        
        }
    )    
    response = {
        'message': 'Item added'
    }
    return {
        'statusCode': 200,
        'body': response
    }